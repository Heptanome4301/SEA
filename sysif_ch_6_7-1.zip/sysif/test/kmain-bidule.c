#include "hw.h"


void bidule()
{
    
}

void kmain()
{
    bidule();
    bidule();
    return;
}

