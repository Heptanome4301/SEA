#include "util.h"

void
kernel_panic(char* string, int number)
{
    for(;;)
    {
        /* do nothing */
    }
}

