

#include "syscall.h"
#include "util.h"
#include "asm_tools.h"
#include <stdint.h>
#include "hw.h"
#include "sched.h"

#define WORD_SIZE 4

#define REBOOT_INT 1
#define NOP_INT 2
#define SYS_TIME 3
#define SYS_TIME_GT 4
#define YIELDTO 5
#define YIELD 6
#define EXIT 7

int pile_context;

void sys_reboot()
{
	__asm("mov r0, %0" : :"r"(REBOOT_INT) : "r0");    // ecriture registre
	__asm("SWI #0");
	//__asm("bl swi_handler");


}


void __attribute__((naked)) swi_handler(void)
{
	//sauvegarde du context
	__asm("stmfd sp!, {r0-r12,lr}");
	__asm("mov %0, sp" : "=r"(pile_context) );  // lecture registre

	int num_intp;
	__asm("mov %0, r0" : "=r"(num_intp ) : : "r0");  // lecture registre


	switch(num_intp)
	{
		case REBOOT_INT :
			do_sys_reboot();			
			break;

		case NOP_INT :
			do_sys_nop();
			break;

		case SYS_TIME :
			
			do_sys_settime();
			break;
		
		case SYS_TIME_GT :
			do_sys_gettime();
			break;

		case YIELDTO :
			do_sys_yieldto();
			break;
		
		case YIELD : 
			do_sys_yield();
			break;
			
		case EXIT:
			do_sys_exit();
			break;

		default :
			PANIC();
		break;
	}

	//restaurer context
	__asm("ldmfd sp!, {r0-r12,pc}^");

}


void do_sys_reboot()
{
	__asm("mov pc, %0" : :"r"(0) ); 

	/*const int PM_RSTC = 0x2010001c;
	const int PM_WDOG = 0x20100024;
	const int PM_PASSWORD = 0x5a000000;
	const int PM_RSTC_WRCFG_FULL_RESET = 0x00000020;

	Set32(PM_WDOG, PM_PASSWORD | 1);
	Set32(PM_RSTC, PM_PASSWORD | PM_RSTC_WRCFG_FULL_RESET);
	while(1);*/

	
}


void sys_nop()
{

	__asm("mov r0, %0" : :"r"(NOP_INT) : "r0");    // ecriture registre
	__asm("SWI #0");

	

}

void do_sys_nop()
{

	//__asm("msr SPSR_svc CPSR");	
	//__asm("b LR_svc");
	
}


void sys_settime(uint64_t date_ms)
{
	
	__asm("mov r0, %0" : :"r"(SYS_TIME) : "r0");    // ecriture registre
	__asm("mov r1, %0" : :"r"(date_ms) : "r1");    // ecriture registre
	__asm("mov r2, %0" : :"r"(date_ms >> 32) : "r2");    // ecriture registre
	__asm("SWI #0");

}


void do_sys_settime()
{
	uint64_t date_ms;
	uint64_t a;
	uint64_t b;

	a = *(int *)(pile_context+sizeof(int));
	b = *(int *)(pile_context+2*sizeof(int));
	date_ms = (a & 0x00000000ffffffff) | (b << 32) ;
	//date_ms = date_ms+1;

	set_date_ms(date_ms);

}


uint64_t sys_gettime()
{
	
	__asm("mov r0, %0" : :"r"(SYS_TIME_GT) : "r0");    // ecriture registre
	__asm("SWI #0");

	uint64_t date_ms;
	uint64_t fort;
	uint64_t faible; 

	__asm("mov %0, r0" : "=r"(faible) );  // lecture registre
	__asm("mov %0, r1" : "=r"(fort) );  // lecture registre


	date_ms = (faible & 0x00000000ffffffff) | (fort << 32) ;

	return date_ms;

}


void do_sys_gettime()
{
	uint64_t date_ms;

	date_ms = get_date_ms();

	*(int *)pile_context = (int)(date_ms & 0x00000000ffffffff) ; // faible
	*(int *)(pile_context+sizeof(int)) = (int)((date_ms & 0xffffffff00000000) >> 32 ) ; // fort

}



void sys_yieldto(pcb_s* dest)
{

	//int tmp;

	__asm("mov r0, %0" : :"r"(YIELDTO) : "r0");    // ecriture registre
	__asm("mov r1, %0" : :"r"(dest) : "r1");    // ecriture registre
	//__asm("mov %0, lr" : "=r"(tmp) );           // lecture registre
	//__asm("mov r2, %0" : :"r"(tmp) : "r2");    // ecriture registre
	__asm("SWI #0");

}




void do_sys_yieldto()
{
	int i;
	int * p_pile_context = (int*)(pile_context);
	int * p_curr_procss = (int*)current_process;


	// Sauvegarde process current
	for(i=0;i<14;i++)
	{
		*(p_curr_procss+i) = *(p_pile_context+i);
	}

	__asm("cps 0b11111");					// passage au mode systeme
	__asm("mov %0, lr" : "=r"(current_process->lr_usr) );   // lecture registre
	__asm("mov %0, sp" : "=r"(current_process->sp) );   	// lecture registre
	__asm("cps 0b10011"); 					// passage au mode svc

	
	__asm("mrs r3,SPSR");
	__asm("mov %0, r3" : "=r"(current_process-> CPSR_user) );   // lecture registre
	

	// echange de context
	current_process = (pcb_s *)(*(p_pile_context +1)) ;    //dest

	for(i=0;i<14;i++)
	{
		*(p_pile_context+i) = *(p_curr_procss+i);
	}

	__asm("cps 0b11111");					// passage au mode systeme
	__asm("mov lr, %0" : :"r"(current_process->lr_usr));    // ecriture registre
	__asm("mov sp, %0" : :"r"(current_process->sp));    	// ecriture registre	
	__asm("cps 0b10011"); 					// passage au mode svc
	
	__asm("mov r3, %0" : :"r"(current_process->CPSR_user) : "r3" );    	// ecriture registre
	__asm("msr SPSR_s,r3"); // normalent SPSR  mais ca marche pas avec ... 
		
}

void  __attribute__((naked)) irq_handler(void)
{
  /* 10 ms seems good */
  set_next_tick_default();
  
  /* Enable timer irq */
  ENABLE_TIMER_IRQ();

  DISABLE_IRQ();
  ENABLE_IRQ();

  //__asm("cps 0b10011"); // passage au mode svc -----------------
  
  //sauvegarde du context
  int tmp;
  __asm("mov %0, lr" : "=r"(tmp) );           // lecture registre
  __asm("mov lr, %0" : :"r"((tmp-4)) );    // ecriture registre

  __asm("stmfd sp!, {r0-r12,lr}");
  __asm("mov %0, sp" : "=r"(pile_context) );  // lecture registre    
  //do_sys_yield();
  __asm("ldmfd sp!, {r0-r12,pc}^");

  //__asm("cps 0b10010"); // passage au mode IRQ ----------------


  /*
__asm("cps 0b11111");					// passage au mode systeme
  sys_yield();
  __asm("cps 0b10010"); // passage au mode IRQ ----------------
  */


 
}



void sys_yield(void)
{

	__asm("mov r0, %0" : :"r"(YIELD) : "r0");    // ecriture registre
	__asm("SWI #0");

}


void do_sys_yield(void)
{
	int i;
	int * p_pile_context = (int*)(pile_context);
	int * p_curr_procss = (int*)current_process;


	// Sauvegarde process current
	for(i=0;i<14;i++)
	{
		*(p_curr_procss+i) = *(p_pile_context+i);
	}

	__asm("cps 0b11111");					// passage au mode systeme
	__asm("mov %0, lr" : "=r"(current_process->lr_usr) );   // lecture registre
	__asm("mov %0, sp" : "=r"(current_process->sp) );   	// lecture registre
	__asm("cps 0b10011"); 					// passage au mode svc

	
	__asm("mrs r3,SPSR");
	__asm("mov %0, r3" : "=r"(current_process-> CPSR_user) );   // lecture registre
	

	// echange de context
	elect();
	//current_process = (pcb_s *)(*(p_pile_context +1)) ;    //dest

	for(i=0;i<14;i++)
	{
		*(p_pile_context+i) = *(p_curr_procss+i);
	}


	__asm("cps 0b11111");					// passage au mode systeme
	__asm("mov lr, %0" : :"r"(current_process->lr_usr));    // ecriture registre
	__asm("mov sp, %0" : :"r"(current_process->sp));    	// ecriture registre	
	__asm("cps 0b10011"); 					// passage au mode svc
	
	__asm("mov r3, %0" : :"r"(current_process->CPSR_user) : "r3" );    	// ecriture registre
	__asm("msr SPSR_s,r3"); // normalent SPSR  mais ca marche pas avec ... 
	
	
	
	
}


void sys_exit(int status)
{
	__asm("mov r0, %0" : :"r"(EXIT) : "r0");    // ecriture registre
	__asm("mov r1, %0" : :"r"(status) : "r1");    // ecriture registre
	__asm("SWI #0");
}
void do_sys_exit()
{
  
	current_process ->TERMINATED = 1;
	__asm("mov %0, r1" : "=r"(current_process -> EXIT_CODE )); 
}

