#include "syscall.h"

#ifndef SCHED_H
#define SCHED_H


typedef  int(func_t) (void);
pcb_s* current_process;

pcb_s* last_process;

void sched_init();

void create_process(func_t* entry); 

void elect();

void start_current_process();

#endif
