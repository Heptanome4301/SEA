#include "kheap.h"
#include "sched.h"
#include "hw.h"


pcb_s kmain_process;



void sched_init()
{
	current_process = &kmain_process;
	last_process = &kmain_process;
	kheap_init();

}


void create_process(func_t* entry)
{
	pcb_s* res = (pcb_s*)kAlloc(sizeof(pcb_s));
	res -> lr_usr = (int)entry;
	
	int*sp = (int*)kAlloc(10000); // 10Ko
	res -> sp = (int*)(((int)sp) +( 10000/4 )) ;

	res ->TERMINATED = 0;

	res -> next_process = kmain_process . next_process ;
	
	last_process->next_process = res;
	last_process = res;

	if(current_process == &kmain_process)
	 current_process = kmain_process.next_process;
}


void elect(){
	
  
  if(current_process->next_process->TERMINATED)
	{
		pcb_s* tmp =  current_process->next_process;
		current_process->next_process = tmp->next_process;

		if(current_process == current_process->next_process)
		  kmain_process .next_process = NULL;

		kFree((void*)tmp->sp,((unsigned int)10000));
		kFree((void*)tmp,((unsigned int)sizeof(pcb_s)));
	}
	
  if( current_process->next_process == NULL )
    terminate_kernel();
  else
    current_process = current_process->next_process;
	
}


void start_current_process(){
  ( (func_t*) (current_process -> lr_usr) )() ;
  sys_exit(0);

}
