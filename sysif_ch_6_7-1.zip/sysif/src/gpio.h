#ifndef __HEADER_GPIO
#define __HEADER_GPIO


//
// Registres du GPIO (seulement ceux qui nous intéressent)
#define GPIO_FSEL1		0x20200004u
#define GPIO_SET0		0x2020001Cu
#define GPIO_CLR0		0x20200028u
#define GPIO_PUD		0x20200094u
#define GPIO_PUDCLK0	0x20200098u


#endif
